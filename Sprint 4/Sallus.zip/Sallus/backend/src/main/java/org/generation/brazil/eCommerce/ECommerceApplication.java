package org.generation.brazil.eCommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author Caique Matheus
 * @author Priscila
 * @author Giovanna
 * @author Luiz Campos
 * @author Vitor Horvath
 */
@SpringBootApplication
public class ECommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECommerceApplication.class, args);
	}
}
