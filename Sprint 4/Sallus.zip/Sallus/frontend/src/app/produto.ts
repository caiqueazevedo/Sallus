export class Produto {
  id: number;
  valor: number;
  nome: string;
  descricao: string;
}
